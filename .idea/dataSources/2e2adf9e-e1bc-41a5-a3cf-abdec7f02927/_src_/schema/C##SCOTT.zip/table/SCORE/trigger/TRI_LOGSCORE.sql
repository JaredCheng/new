CREATE TRIGGER TRI_LOGSCORE
BEFORE INSERT
  ON SCORE
FOR EACH ROW
  DECLARE
BEGIN
      IF inserting THEN
       INSERT INTO logs(log_dml,LOG_OLDSCORE,log_NEWSCORE,log_date,log_user) VALUES
           ('insert',
            :old.chinese ||';'||  :old.math||';' || :old.english|| ';'|| :old.complex,
            :new.chinese ||';'||  :new.math||';' || :new.english|| ';'|| :new.complex,
            Sysdate,
            USER);
    ELSIF deleting THEN
       INSERT INTO logs(log_dml,LOG_OLDSCORE,log_NEWSCORE,log_date,log_user) VALUES
            ('insert',
            :old.chinese ||';'||  :old.math||';' || :old.english|| ';'|| :old.complex,
            :new.chinese ||';'||  :new.math||';' || :new.english|| ';'|| :new.complex,
            Sysdate,
            USER);
    ELSE
       INSERT INTO logs(log_dml,LOG_OLDSCORE,log_NEWSCORE,log_date,log_user) VALUES
             ('insert',
            :old.chinese ||';'||  :old.math||';' || :old.english|| ';'|| :old.complex,
            :new.chinese ||';'||  :new.math||';' || :new.english|| ';'|| :new.complex,
            Sysdate,
            USER);
    END IF;
END;
/
