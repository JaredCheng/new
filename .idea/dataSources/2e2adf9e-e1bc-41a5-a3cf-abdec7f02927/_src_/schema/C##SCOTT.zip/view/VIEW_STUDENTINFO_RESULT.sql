CREATE VIEW VIEW_STUDENTINFO_RESULT AS SELECT ma.stuid,chinese+math+english+complex totalscore,chinese,math,english,complex,MAT_FLAG,co.NAME collegename,MAT_WILL_FLAG
  from SCORE sc,MAT ma,COLLEGE co
  where 
        ma.STUID=sc.STUID
        AND ma.MAT_COLLEGEID=co.COLLEGEID
/
