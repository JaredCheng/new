CREATE VIEW VIEW_STUDENTINFO AS SELECT ma.stuid,st.name,chinese+math+english+complex totalscore,chinese,math,english,complex,first_will,co1.NAME first_will_name,second_will,co2.NAME second_will_name
  from STUDENT st,SCORE sc,MAT ma,COLLEGE co1,COLLEGE co2
  where st.STUID=sc.STUID
        AND ma.STUID=st.STUID
        AND ma.STUID=sc.STUID
        AND ma.FIRST_WILL=co1.COLLEGEID
        AND ma.SECOND_WILL=co2.COLLEGEID
/
