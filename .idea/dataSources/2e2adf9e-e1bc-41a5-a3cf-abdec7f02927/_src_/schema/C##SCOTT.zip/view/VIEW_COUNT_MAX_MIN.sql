CREATE VIEW VIEW_COUNT_MAX_MIN AS SELECT mat_collegeid,max(totalscore) maxscore,min(totalscore) minscore
  from view_studentinfo_all
  where mat_flag=1
  group by mat_collegeid
/
