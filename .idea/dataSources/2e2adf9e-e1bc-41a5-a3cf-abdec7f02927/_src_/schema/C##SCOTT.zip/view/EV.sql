CREATE VIEW EV AS SELECT empno,ename,job FROM emp
/
