CREATE procedure clear_status as
begin

  update college
  set actual_total=0;

  update mat
  set mat_flag=0,
      mat_collegeid=null,
      mat_will_flag=null,
      mat_date=null,
      operator=null;

  commit;
  exception
      when others then
           rollback;

end clear_status;
/
