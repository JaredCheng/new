CREATE procedure STUDENT_LIST(p_collegeid in number) as  
cursor v_stu is  
select stuid,name,totalscore,totalscore/4 as avgscore,  
       chinese,math,english,complex,  
       first_will,first_will_name,second_will,second_will_name,  
       mat_flag,mat_collegeid,mat_will_flag  
from view_studentinfo_all  
where mat_collegeid=p_collegeid  
order by totalscore desc;  
  
score float:=0;  
i integer:=0;  
  
begin  
  
for v_record in v_stu loop  
dbms_output.put_line('报名序号:'||v_record.stuid||'姓名:'||v_record.name||'分数:'||v_record.totalscore||'志愿:'||v_record.mat_will_flag);  
score:=score+v_record.totalscore;  
i:=i+1;  
end loop;  
  
dbms_output.put_line('总分:'||score);  
dbms_output.put_line('平均分:'||score/i);  
    
end STUDENT_LIST;
/
