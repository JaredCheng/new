CREATE procedure COLLEGE_TOTAL as
cursor v_cur is
select mat_collegeid,avg(totalscore) as avgscore
from view_studentinfo_all
where mat_flag=1
group by mat_collegeid
order by avgscore desc;

max_min_score view_count_max_min%rowtype;
collegeinfo college%rowtype;

  cursor v_num(p_collegeid_tmp number) is
select count(decode(sex,0,'man')) man, count(decode(sex,1,'woman')) woman
from mat,student
  where mat_flag=1 and mat.stuid=student.stuid
  and mat.mat_collegeid=p_collegeid_tmp;



begin
  for v_record in v_cur loop
  --统计各院校的最高分数、最低分数
  select mat_collegeid,maxscore,minscore into max_min_score
  from view_count_max_min
  where mat_collegeid=v_record.mat_collegeid;
  dbms_output.put_line('学校编号:'||max_min_score.mat_collegeid);
  dbms_output.put_line('最高分:'||max_min_score.maxscore||'最低分:'||max_min_score.minscore);

  --招生人数、录取人数
  select * into collegeinfo
  from college
  where collegeid=v_record.mat_collegeid;
  dbms_output.put_line('计划招生数:'||collegeinfo.plan_total);
  dbms_output.put_line('实际录取数:'||collegeinfo.actual_total);

  --男生人数、女生人数
      for v_record_2 in v_num(v_record.mat_collegeid) loop
         dbms_output.put_line('女生:'||v_record_2.woman||',男生:'||v_record_2.man);

      end loop;
  end loop;
end COLLEGE_TOTAL;
/
