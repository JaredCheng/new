CREATE procedure show_score(p_stuid in number) as
  v_stu view_studentinfo%rowtype;
begin
  select stuid,name,totalscore,
         chinese,math,english,complex,
         first_will,first_will_name,
         second_will,second_will_name
  into v_stu
  from view_studentinfo
  where stuid=p_stuid;

  dbms_output.put_line(v_stu.stuid);
  dbms_output.put_line(v_stu.name);
  dbms_output.put_line(v_stu.totalscore);
  dbms_output.put_line(v_stu.chinese);
  dbms_output.put_line(v_stu.math);
  dbms_output.put_line(v_stu.english);
  dbms_output.put_line(v_stu.complex);
  dbms_output.put_line(v_stu.first_will);
  dbms_output.put_line(v_stu.first_will_name);
  dbms_output.put_line(v_stu.second_will);
  dbms_output.put_line(v_stu.second_will_name);


  exception
        when others then
             dbms_output.put_line('error');
end show_score;
/
