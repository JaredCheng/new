CREATE PROCEDURE show_result(p_stuid in NUMBER) AS
  v_stu view_studentinfo_result%rowtype;
BEGIN
   select stuid,totalscore,
         chinese,math,english,complex,
         MAT_FLAG,collegename,mat_will_flag
     into v_stu
     FROM view_studentinfo_result
    WHERE STUID=p_stuid;

    dbms_output.put_line('学生编号:'||v_stu.stuid);
  dbms_output.put_line('总分:'||v_stu.totalscore);
  dbms_output.put_line(v_stu.chinese);
  dbms_output.put_line(v_stu.math);
  dbms_output.put_line(v_stu.english);
  dbms_output.put_line(v_stu.complex);
  dbms_output.put_line('是否录取:'||v_stu.MAT_FLAG);
  dbms_output.put_line('录取院校:'||v_stu.collegename);
  dbms_output.put_line('录取志愿:'||v_stu.mat_will_flag);

   exception
        when others then
             dbms_output.put_line('error');
END;
/
