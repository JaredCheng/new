CREATE procedure get_students(p_stuid in number) is
cursor v_stu is
select *
from view_studentinfo_result
where MAT_FLAG=1
      and collegename=(
                    select collegename
                    from VIEW_STUDENTINFO_RESULT
                    where stuid=p_stuid
                    )
      and totalscore>(
                    select chinese+math+english+complex as totalscore
                    from score
                    where stuid=p_stuid
                    );
begin

for v_record in v_stu loop
  dbms_output.put_line(v_record.stuid);
  dbms_output.put_line(v_record.totalscore);
  dbms_output.put_line(v_record.chinese);
  dbms_output.put_line(v_record.math);
  dbms_output.put_line(v_record.english);
  dbms_output.put_line(v_record.complex);
  dbms_output.put_line('录取志愿:'||v_record.mat_will_flag);
end loop;

end get_students;
/
