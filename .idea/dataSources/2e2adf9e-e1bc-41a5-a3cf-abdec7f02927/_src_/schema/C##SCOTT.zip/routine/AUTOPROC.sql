CREATE procedure autoproc(will_number in number) as  
cursor v_college is  
       select *  
       from college;  
begin  
if(will_number=1) then  
   for v_record in v_college loop  
        proc1(v_record.collegeid);  
   end loop;  
elsif (will_number=2) then  
  for v_record in v_college loop  
        proc2(v_record.collegeid);  
   end loop;  
end if;  
commit;  
exception  
    when others then  
         rollback;  
end;
/
