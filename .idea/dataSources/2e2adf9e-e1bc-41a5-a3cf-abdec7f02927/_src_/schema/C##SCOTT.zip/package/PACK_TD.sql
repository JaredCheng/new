CREATE PACKAGE pack_td AS
 PROCEDURE autoproc(will_number in number);
 PROCEDURE clear_status;
 PROCEDURE COLLEGE_TOTAL;
 procedure get_students(p_stuid in number);
  PROCEDURE PROC1(P_COLLEGEID IN NUMBER);
  PROCEDURE PROC2(P_COLLEGEID IN NUMBER);
  PROCEDURE show_result(p_stuid in NUMBER);
  procedure show_score(p_stuid in number);
  procedure STUDENT_LIST(p_collegeid in number);
END ;
/
