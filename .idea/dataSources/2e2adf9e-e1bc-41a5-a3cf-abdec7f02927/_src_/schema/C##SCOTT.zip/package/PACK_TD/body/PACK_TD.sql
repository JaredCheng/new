CREATE PACKAGE BODY PACK_TD AS

PROCEDURE PROC1(P_COLLEGEID IN NUMBER)
IS
  V_COLLEGE COLLEGE%ROWTYPE;
CURSOR V_STU(V_stu_grade NUMBER,v_stu_plantotal NUMBER,V_STU_COLLEGEID NUMBER) IS
   SELECT M.STUID,FIRST_WILL
   FROM SCORE S,MAT M
   WHERE S.STUID=M.STUID
        AND chinese+math+english+complex>=v_stu_plantotal
        AND ROWNUM<=v_stu_plantotal
        AND MAT_FLAG=0
        AND FIRST_WILL=V_STU_COLLEGEID
        ORDER BY chinese+math+english+complex desc;
BEGIN
    SELECT * INTO V_COLLEGE FROM COLLEGE WHERE COLLEGEID=P_COLLEGEID;
    DBMS_OUTPUT.PUT_LINE('该大学的最低录取分数为'||V_COLLEGE.GRADE);
    FOR V_STU_TEMP IN V_STU(V_COLLEGE.GRADE,(V_COLLEGE.PLAN_TOTAL-V_COLLEGE.ACTUAL_TOTAL),P_COLLEGEID) LOOP
    DBMS_OUTPUT.PUT_LINE('学生编号：'||V_STU_TEMP.STUID||',第一志愿：'||V_STU_TEMP.FIRST_WILL);
    UPDATE MAT
    SET MAT_FLAG=1,
        MAT_COLLEGEID=P_COLLEGEID,
        MAT_WILL_FLAG=2,
        MAT_DATE=SYSDATE,
        OPERATOR='CTQ'
    WHERE STUID=V_STU_TEMP.STUID;--修改MAT表

    UPDATE COLLEGE SET ACTUAL_TOTAL=ACTUAL_TOTAL+1 WHERE COLLEGEID=P_COLLEGEID; --修改COLLEGE信息
   END LOOP;
  commit;
  EXCEPTION
     when OTHERS THEN
        ROLLBACK;
     DBMS_OUTPUT.PUT_LINE('error');
END;

PROCEDURE PROC2(P_COLLEGEID IN NUMBER)
IS
  V_COLLEGE COLLEGE%ROWTYPE;
CURSOR V_STU(V_stu_grade NUMBER,v_stu_plantotal NUMBER,V_STU_COLLEGEID NUMBER) IS
   SELECT M.STUID,SECOND_WILL
   FROM SCORE S,MAT M
   WHERE S.STUID=M.STUID
        AND chinese+math+english+complex>=v_stu_plantotal
        AND ROWNUM<=v_stu_plantotal
        AND MAT_FLAG=0
        AND SECOND_WILL=V_STU_COLLEGEID
        ORDER BY chinese+math+english+complex desc;
BEGIN
    SELECT * INTO V_COLLEGE FROM COLLEGE WHERE COLLEGEID=P_COLLEGEID;
    DBMS_OUTPUT.PUT_LINE('该大学的最低录取分数为'||V_COLLEGE.GRADE);
    FOR V_STU_TEMP IN V_STU(V_COLLEGE.GRADE,(V_COLLEGE.PLAN_TOTAL-V_COLLEGE.ACTUAL_TOTAL),P_COLLEGEID) LOOP
    DBMS_OUTPUT.PUT_LINE('学生编号：'||V_STU_TEMP.STUID||',第二志愿：'||V_STU_TEMP.SECOND_WILL);
    UPDATE MAT
    SET MAT_FLAG=1,
        MAT_COLLEGEID=P_COLLEGEID,
        MAT_WILL_FLAG=2,
        MAT_DATE=SYSDATE,
        OPERATOR='CTQ'
    WHERE STUID=V_STU_TEMP.STUID;--修改MAT表

    UPDATE COLLEGE SET ACTUAL_TOTAL=ACTUAL_TOTAL+1 WHERE COLLEGEID=P_COLLEGEID; --修改COLLEGE信息
   END LOOP;
  commit;
  EXCEPTION
     when OTHERS THEN
        ROLLBACK;
     DBMS_OUTPUT.PUT_LINE('error');
END;

procedure autoproc(will_number in number) as
cursor v_college is
       select *
       from college;
begin
if(will_number=1) then
   for v_record in v_college loop
        proc1(v_record.collegeid);
   end loop;
elsif (will_number=2) then
  for v_record in v_college loop
        proc2(v_record.collegeid);
   end loop;
end if;
commit;
exception
    when others then
         rollback;
end;
--视图
/*
create or REPLACE VIEW view_studentinfo AS
  SELECT ma.stuid,st.name,chinese+math+english+complex totalscore,chinese,math,english,complex,first_will,co1.NAME first_will_name,second_will,co2.NAME second_will_name
  from STUDENT st,SCORE sc,MAT ma,COLLEGE co1,COLLEGE co2
  where st.STUID=sc.STUID
        AND ma.STUID=st.STUID
        AND ma.STUID=sc.STUID
        AND ma.FIRST_WILL=co1.COLLEGEID
        AND ma.SECOND_WILL=co2.COLLEGEID;

create or REPLACE VIEW view_studentinfo_result AS
  SELECT ma.stuid,chinese+math+english+complex totalscore,chinese,math,english,complex,MAT_FLAG,co.NAME collegename,MAT_WILL_FLAG
  from SCORE sc,MAT ma,COLLEGE co
  where
        ma.STUID=sc.STUID
        AND ma.MAT_COLLEGEID=co.COLLEGEID;

create or REPLACE VIEW view_studentinfo_all AS
  SELECT ma.stuid,st.name,chinese+math+english+complex totalscore,chinese,math,english,complex,first_will,co1.NAME first_will_name,second_will,co2.NAME second_will_name,MAT_FLAG,MAT_COLLEGEID,MAT_WILL_FLAG
  from STUDENT st,SCORE sc,MAT ma,COLLEGE co1,COLLEGE co2
  where st.STUID=sc.STUID
        AND ma.STUID=st.STUID
        AND ma.STUID=sc.STUID
        AND ma.FIRST_WILL=co1.COLLEGEID
        AND ma.SECOND_WILL=co2.COLLEGEID;

create or REPLACE VIEW view_count_max_min AS
  SELECT mat_collegeid,max(totalscore) maxscore,min(totalscore) minscore
  from view_studentinfo_all
  where mat_flag=1
  group by mat_collegeid;
*/

procedure show_score(p_stuid in number) as
  v_stu view_studentinfo%rowtype;
begin
  select stuid,name,totalscore,
         chinese,math,english,complex,
         first_will,first_will_name,
         second_will,second_will_name
  into v_stu
  from view_studentinfo
  where stuid=p_stuid;

  dbms_output.put_line(v_stu.stuid);
  dbms_output.put_line(v_stu.name);
  dbms_output.put_line(v_stu.totalscore);
  dbms_output.put_line(v_stu.chinese);
  dbms_output.put_line(v_stu.math);
  dbms_output.put_line(v_stu.english);
  dbms_output.put_line(v_stu.complex);
  dbms_output.put_line(v_stu.first_will);
  dbms_output.put_line(v_stu.first_will_name);
  dbms_output.put_line(v_stu.second_will);
  dbms_output.put_line(v_stu.second_will_name);


  exception
        when others then
             dbms_output.put_line('error');
end show_score;

procedure clear_status as
begin

  update college
  set actual_total=0;

  update mat
  set mat_flag=0,
      mat_collegeid=null,
      mat_will_flag=null,
      mat_date=null,
      operator=null;

  commit;
  exception
      when others then
           rollback;

end clear_status;

PROCEDURE show_result(p_stuid in NUMBER) AS
  v_stu view_studentinfo_result%rowtype;
BEGIN
   select stuid,totalscore,
         chinese,math,english,complex,
         MAT_FLAG,collegename,mat_will_flag
     into v_stu
     FROM view_studentinfo_result
    WHERE STUID=p_stuid;

    dbms_output.put_line(v_stu.stuid);
  dbms_output.put_line(v_stu.totalscore);
  dbms_output.put_line(v_stu.chinese);
  dbms_output.put_line(v_stu.math);
  dbms_output.put_line(v_stu.english);
  dbms_output.put_line(v_stu.complex);
  dbms_output.put_line(v_stu.MAT_FLAG);
  dbms_output.put_line('录取院校:'||v_stu.collegename);
  dbms_output.put_line('录取志愿:'||v_stu.mat_will_flag);

   exception
        when others then
             dbms_output.put_line('error');
END;


procedure get_students(p_stuid in number) is
cursor v_stu is
select *
from view_studentinfo_result
where MAT_FLAG=1
      and collegename=(
                    select collegename
                    from VIEW_STUDENTINFO_RESULT
                    where stuid=p_stuid
                    )
      and totalscore>(
                    select chinese+math+english+complex as totalscore
                    from score
                    where stuid=p_stuid
                    );
begin

for v_record in v_stu loop
  dbms_output.put_line(v_stu.stuid);
  dbms_output.put_line(v_stu.totalscore);
  dbms_output.put_line(v_stu.chinese);
  dbms_output.put_line(v_stu.math);
  dbms_output.put_line(v_stu.english);
  dbms_output.put_line(v_stu.complex);
  dbms_output.put_line('录取志愿:'||v_stu.mat_will_flag);
end loop;

end get_students;

procedure STUDENT_LIST(p_collegeid in number) as
cursor v_stu is
select stuid,name,totalscore,totalscore/4 as avgscore,
       chinese,math,english,complex,
       first_will,first_will_name,second_will,second_will_name,
       mat_flag,mat_collegeid,mat_will_flag
from view_studentinfo_all
where mat_collegeid=p_collegeid
order by totalscore desc;

score float:=0;
i integer:=0;

begin

for v_record in v_stu loop
dbms_output.put_line('报名序号:'||v_record.stuid||'姓名:'||v_record.name||'分数:'||v_record.totalscore||'志愿:'||v_record.mat_will_flag);
score:=score+v_record.totalscore;
i:=i+1;
end loop;

dbms_output.put_line('总分:'||score);
dbms_output.put_line('平均分:'||score/i);

end STUDENT_LIST;


procedure COLLEGE_TOTAL as
cursor v_cur is
select mat_collegeid,avg(totalscore) as avgscore
from view_studentinfo_all
where mat_flag=1
group by mat_collegeid
order by avgscore desc;

max_min_score view_count_max_min%rowtype;
collegeinfo college%rowtype;

cursor v_num(p_collegeid_tmp number) is
select count(*) as num
from mat,student
  where mat_flag=1 and mat.stuid=student.stuid
  and mat.mat_collegeid=p_collegeid_tmp
  and student.sex=0
union
select count(*) as num
from mat,student
  where mat_flag=1 and mat.stuid=student.stuid
  and mat.mat_collegeid=p_collegeid_tmp
  and student.sex=1;


begin
  for v_record in v_cur loop
  --统计各院校的最高分数、最低分数
  select mat_collegeid,maxscore,minscore into max_min_score
  from view_count_max_min
  where mat_collegeid=v_record.mat_collegeid;
  dbms_output.put_line(max_min_score.mat_collegeid);
  dbms_output.put_line('最高分:'||max_min_score.maxscore||'最低分:'||max_min_score.minscore);

  --招生人数、录取人数
  select * into collegeinfo
  from college
  where collegeid=v_record.mat_collegeid;
  dbms_output.put_line('计划招生数:'||collegeinfo.plan_total);
  dbms_output.put_line('实际录取数:'||collegeinfo.actual_total);

  --男生人数、女生人数
      for v_record_2 in v_num(v_record.mat_collegeid) loop
         dbms_output.put_line(v_record_2.num);
      end loop;
  end loop;
end COLLEGE_TOTAL;
END PACK_TD;
/
